package libararyManagement;

public class Book {
	private String title;
    private String author;
    private String isbn;
    private boolean isBorrowed;
    private String borrower;

    // Constructor
    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.isBorrowed = false; // Initially, the book is available.
        this.borrower = null;
    }

    // Getters and Setters
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getIsbn() { return isbn; }
    public boolean isBorrowed() { return isBorrowed; }
    public String getBorrower() { return borrower; }

    //mark as borrowed by specific person 
    public void borrowBook(String borrower) {
        this.isBorrowed = true;
        this.borrower = borrower;
    }
    
    //Mark as returned 
    public void returnBook() {
        this.isBorrowed = false;
        this.borrower = null;
    }

    // Display Book Details
    public void displayBook() {
        System.out.println("Title: " + title + ", Author: " + author + ", ISBN: " + isbn);
        if (isBorrowed) {
            System.out.println("Borrowed by: " + borrower);
        } else {
            System.out.println("Available");
        }
    }
}
