package libararyManagement;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//manages the collection of books and borrowing/returning operations 
public class library {
	private List<Book> books = new ArrayList<>();
    private Map<String, String> borrowedBooks = new HashMap<>();

    //adds a book to the library 
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book.getTitle());
    }

    //deletes a book by its ISBN 
    public void deleteBook(String isbn) {
        books.removeIf(book -> book.getIsbn().equals(isbn));
        System.out.println("Book deleted.");
    }

    //searches for books by title or author 
    public void searchBook(String query) {
        for (Book book : books) {
            if (book.getTitle().contains(query) || book.getAuthor().contains(query)) {
                book.displayBook();
            }
        }
    }

    //displays all books sorted by title 
    public void displayAllBooks() {
        books.sort(Comparator.comparing(Book::getTitle));
        for (Book book : books) {
            book.displayBook();
        }
    }

    //borrows a book by ISBN for a borrower 
    public void borrowBook(String isbn, String borrower) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn) && !book.isBorrowed()) {
                book.borrowBook(borrower);
                borrowedBooks.put(isbn, borrower);
                System.out.println("Book borrowed successfully by " + borrower);
                return;
            }
        }
        System.out.println("Book not available for borrowing.");
    }

    //returns a borrowed book by ISBN 
    public void returnBook(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn) && book.isBorrowed()) {
                book.returnBook();
                borrowedBooks.remove(isbn);
                System.out.println("Book returned successfully.");
                return;
            }
        }
        System.out.println("No such book is borrowed.");
    }
}
