package libararyManagement;

public class BST {
	private TreeNode root;

    // Insert a book into the tree
    public void insert(Book book) {
        root = insertRec(root, book);
    }

    private TreeNode insertRec(TreeNode root, Book book) {
        if (root == null) {
        	//i current node is null, create a new node 
            root = new TreeNode(book);
            return root;
        }
        //compare book ISBN for insertion into right or left subtree 
        if (book.getIsbn().compareTo(root.book.getIsbn()) < 0)
            root.left = insertRec(root.left, book);
        else if (book.getIsbn().compareTo(root.book.getIsbn()) > 0)
            root.right = insertRec(root.right, book);

        return root;//returm current root 
    }

    // Search for a book by ISBN
    public Book search(String isbn) {
        return searchRec(root, isbn);
    }

    private Book searchRec(TreeNode root, String isbn) {
        if (root == null || root.book.getIsbn().equals(isbn))
            return (root != null) ? root.book : null;

        if (isbn.compareTo(root.book.getIsbn()) < 0)
            return searchRec(root.left, isbn);

        return searchRec(root.right, isbn);
    }

    // In-order traversal to display books in sorted order
    public void inOrderDisplay() {
        inOrderRec(root);
    }

    private void inOrderRec(TreeNode root) {
        if (root != null) {
            inOrderRec(root.left);
            System.out.println(root.book);
            inOrderRec(root.right);
        }
    }
}
