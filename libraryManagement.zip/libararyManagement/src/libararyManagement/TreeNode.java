package libararyManagement;

public class TreeNode {
	Book book;
    TreeNode left, right;

    public TreeNode(Book book) {
        this.book = book;
        left = right = null;
    }
}
